<?php include('layouts/header.php'); ?>



    <!-- Contact-->
    <section id="contact" class="container my-5 py-5">
        <div class="container text-center mt-5">
            <h3>Contact Us</h3>
            <hr style="background-color: #fb774b;"  class="mx-auto" >
            <p class="w-50 mx-auto">
                Phone number : <span>123 456 789</span>
            </p>
            <p class="w-50 mx-auto">
                Email address : <span>yassine@email.com</span>
            </p>
            <p class="w-50 mx-auto">
                We work 24/7 to answer your questions
            </p>
        </div>

    </section>







     
    
    
    
    
    <?php include('layouts/footer.php') ;?>