<?php


$conn = mysqli_connect("localhost","root","","php_project")
        or die ("Couldn't connect to database");



?>

